#include "negativeColorPicker.h"

NegativeColorPicker::NegativeColorPicker(PNG& inputimg)
{
  /* your code here */
}

HSLAPixel NegativeColorPicker::operator()(point p)
{
  /* your code here */
}
